Occu-Med Provider Intelligence Command Center patch

What this gives you:
- Full polished React/Vite prototype homepage
- Liquid Glass / purple luminous internal-tool UI
- Dashboard, coverage map, provider database, search controls, saved searches, review queue, provider detail drawer
- Mock data and simulated crawler/search workflow

Where to put files:
1. Replace your existing:
   app/frontend/src/pages/Index.tsx
   with:
   frontend/src/pages/Index.tsx

2. Copy these image files into:
   app/frontend/public/

   frontend/public/clinic-placeholder.png
   frontend/public/crawl-bg.png
   frontend/public/dashboard-bg.png
   frontend/public/hero-us-map-glow.png

3. Your existing App.tsx already points / to Index.tsx, so no App.tsx change should be required.

4. Run:
   cd app/frontend
   pnpm install
   pnpm build

Important limitation:
This is a fully usable frontend prototype with mock/simulated data. It does not actually crawl the internet yet. The UI is structured so backend/API integrations can be added next.
