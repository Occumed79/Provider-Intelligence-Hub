import React, { useMemo, useState } from 'react';
import {
  Activity,
  Building2,
  CheckCircle2,
  ChevronRight,
  ClipboardCheck,
  Database,
  FileCheck2,
  Filter,
  Globe2,
  Layers3,
  MapPin,
  Network,
  Pause,
  Phone,
  Play,
  Radar,
  Search,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  Table2,
  Target,
  X,
  Zap,
} from 'lucide-react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

type TriState = 'Yes' | 'No' | 'Unknown';
type VerificationStatus = 'Verified' | 'Needs Review' | 'Unverified';
type SearchStatus = 'Running' | 'Queued' | 'Paused' | 'Complete';

type Provider = {
  id: number;
  name: string;
  type: string;
  city: string;
  state: string;
  zip: string;
  address: string;
  phone: string;
  fax: string;
  website: string;
  services: string[];
  employerAccount: TriState;
  corporateAccount: TriState;
  tpaFriendly: TriState;
  standingAccount: TriState;
  invoiceBilling: TriState;
  net30: TriState;
  acceptsOutsideForms: TriState;
  paymentAtService: TriState;
  requiresAgreement: TriState;
  verification: VerificationStatus;
  confidence: number;
  lastReviewed: string;
  source: string;
  notes: string;
  x: number;
  y: number;
};

type SearchJob = {
  id: number;
  name: string;
  query: string;
  area: string;
  zipScanned: number;
  providersFound: number;
  highValue: number;
  status: SearchStatus;
  progress: number;
};

const services = [
  'General Physical Exam',
  'DOT Exam and Certificate',
  'FAA Flight Physicals',
  'Vision testing',
  'Audiogram with headset',
  'OSHA sound booth audiogram',
  'PPD / TB skin test',
  'Chest X-ray with interpretation',
  'Resting 12-lead EKG',
  'Treadmill stress test',
  'Pulmonary function test',
  'Respirator fit test',
  'Venipuncture collection',
  'Urine drug screen collection',
  'Breath alcohol test',
  'Hepatitis A',
  'Hepatitis B',
  'Influenza',
  'MMR',
  'Rabies',
  'Tdap',
  'Typhoid injection',
  'Yellow Fever',
  'Meningococcal vaccines',
  'Comprehensive dental evaluation',
];

const providersSeed: Provider[] = [
  {
    id: 1,
    name: 'Central Valley Workforce Health',
    type: 'Occupational Health Clinic',
    city: 'Fresno',
    state: 'CA',
    zip: '93720',
    address: '7421 N Medical Plaza Ave',
    phone: '(559) 555-0128',
    fax: '(559) 555-0182',
    website: 'centralvalleyworkforce.example',
    services: ['General Physical Exam', 'DOT Exam and Certificate', 'Resting 12-lead EKG', 'PPD / TB skin test', 'Urine drug screen collection'],
    employerAccount: 'Yes',
    corporateAccount: 'Yes',
    tpaFriendly: 'Yes',
    standingAccount: 'Yes',
    invoiceBilling: 'Yes',
    net30: 'Unknown',
    acceptsOutsideForms: 'Yes',
    paymentAtService: 'No',
    requiresAgreement: 'Yes',
    verification: 'Verified',
    confidence: 94,
    lastReviewed: 'Today',
    source: 'Employer services page, account setup form',
    notes: 'Strong employer-services language. Ask for pricing sheet and PSA confirmation.',
    x: 17,
    y: 52,
  },
  {
    id: 2,
    name: 'Metro Urgent Care Employer Services',
    type: 'Urgent Care Employer Services',
    city: 'Dallas',
    state: 'TX',
    zip: '75231',
    address: '1910 Skillman Occupational Pkwy',
    phone: '(214) 555-0199',
    fax: '(214) 555-0104',
    website: 'metroemployercare.example',
    services: ['General Physical Exam', 'DOT Exam and Certificate', 'Chest X-ray with interpretation', 'Pulmonary function test', 'Breath alcohol test'],
    employerAccount: 'Yes',
    corporateAccount: 'Yes',
    tpaFriendly: 'Unknown',
    standingAccount: 'Yes',
    invoiceBilling: 'Yes',
    net30: 'Yes',
    acceptsOutsideForms: 'Unknown',
    paymentAtService: 'No',
    requiresAgreement: 'Yes',
    verification: 'Needs Review',
    confidence: 87,
    lastReviewed: 'Yesterday',
    source: 'Corporate billing page',
    notes: 'Likely high-value. Confirm outside employer forms and treadmill stress test options.',
    x: 51,
    y: 65,
  },
  {
    id: 3,
    name: 'Northeast Imaging & Radiology Partners',
    type: 'Imaging / Radiology Center',
    city: 'Wilkes-Barre',
    state: 'PA',
    zip: '18702',
    address: '210 Ridgeview Imaging Dr',
    phone: '(570) 555-0140',
    fax: '(570) 555-0155',
    website: 'neimagingpartners.example',
    services: ['Chest X-ray with interpretation'],
    employerAccount: 'Unknown',
    corporateAccount: 'Unknown',
    tpaFriendly: 'Unknown',
    standingAccount: 'No',
    invoiceBilling: 'Unknown',
    net30: 'Unknown',
    acceptsOutsideForms: 'Yes',
    paymentAtService: 'Yes',
    requiresAgreement: 'No',
    verification: 'Unverified',
    confidence: 74,
    lastReviewed: '3 days ago',
    source: 'Radiology service menu',
    notes: 'Good for standalone CXR if employer account is not required.',
    x: 79,
    y: 39,
  },
  {
    id: 4,
    name: 'Rocky Mountain Corporate Medicine',
    type: 'Hospital Occupational Medicine Department',
    city: 'Denver',
    state: 'CO',
    zip: '80220',
    address: '80 E Health Systems Blvd',
    phone: '(303) 555-0171',
    fax: '(303) 555-0188',
    website: 'rmcorporatemedicine.example',
    services: ['General Physical Exam', 'Audiogram with headset', 'OSHA sound booth audiogram', 'Pulmonary function test', 'Respirator fit test'],
    employerAccount: 'Yes',
    corporateAccount: 'Yes',
    tpaFriendly: 'Yes',
    standingAccount: 'Unknown',
    invoiceBilling: 'Yes',
    net30: 'Yes',
    acceptsOutsideForms: 'Yes',
    paymentAtService: 'No',
    requiresAgreement: 'Yes',
    verification: 'Verified',
    confidence: 96,
    lastReviewed: 'Today',
    source: 'Occupational medicine department page',
    notes: 'Excellent fit for bundled employer testing. Confirm vaccine list.',
    x: 39,
    y: 50,
  },
  {
    id: 5,
    name: 'Atlantic Travel Vaccine & Work Clearance',
    type: 'Vaccine / Travel Medicine',
    city: 'Dover',
    state: 'DE',
    zip: '19904',
    address: '59 Expedition Health Way',
    phone: '(302) 555-0162',
    fax: '(302) 555-0122',
    website: 'atlantictravelwork.example',
    services: ['Hepatitis A', 'Hepatitis B', 'Rabies', 'Tdap', 'Typhoid injection', 'Yellow Fever', 'Meningococcal vaccines'],
    employerAccount: 'Unknown',
    corporateAccount: 'Unknown',
    tpaFriendly: 'No',
    standingAccount: 'Unknown',
    invoiceBilling: 'No',
    net30: 'No',
    acceptsOutsideForms: 'Yes',
    paymentAtService: 'Yes',
    requiresAgreement: 'No',
    verification: 'Needs Review',
    confidence: 82,
    lastReviewed: '2 days ago',
    source: 'Travel immunization list',
    notes: 'Likely payment at time of service. Useful for hard-to-source vaccines.',
    x: 82,
    y: 45,
  },
  {
    id: 6,
    name: 'Great Lakes Audiology Screening Group',
    type: 'Audiology Provider',
    city: 'Toledo',
    state: 'OH',
    zip: '43606',
    address: '3100 Hearing Science Ct',
    phone: '(419) 555-0191',
    fax: '(419) 555-0192',
    website: 'glaudiology.example',
    services: ['Audiogram with headset', 'OSHA sound booth audiogram'],
    employerAccount: 'Yes',
    corporateAccount: 'Unknown',
    tpaFriendly: 'Unknown',
    standingAccount: 'Unknown',
    invoiceBilling: 'Unknown',
    net30: 'Unknown',
    acceptsOutsideForms: 'Yes',
    paymentAtService: 'Unknown',
    requiresAgreement: 'Unknown',
    verification: 'Unverified',
    confidence: 71,
    lastReviewed: '5 days ago',
    source: 'Industrial hearing conservation page',
    notes: 'Ask if DD2215 can be completed and if calibration date can be documented.',
    x: 70,
    y: 38,
  },
  {
    id: 7,
    name: 'South Orange Employer Care Cardiology',
    type: 'Cardiology / Stress Testing',
    city: 'Orlando',
    state: 'FL',
    zip: '32806',
    address: '2609 S Orange Ave',
    phone: '(407) 555-2926',
    fax: '(407) 555-2927',
    website: 'southorangeemployercare.example',
    services: ['Resting 12-lead EKG', 'Treadmill stress test'],
    employerAccount: 'Yes',
    corporateAccount: 'Yes',
    tpaFriendly: 'Unknown',
    standingAccount: 'Unknown',
    invoiceBilling: 'Unknown',
    net30: 'Unknown',
    acceptsOutsideForms: 'Unknown',
    paymentAtService: 'Unknown',
    requiresAgreement: 'Unknown',
    verification: 'Needs Review',
    confidence: 79,
    lastReviewed: 'Today',
    source: 'Employer care location note',
    notes: 'Confirm exact stress-test availability days and interpretation turnaround.',
    x: 74,
    y: 73,
  },
  {
    id: 8,
    name: 'Northwest Dental Exam Partners',
    type: 'Dental Provider',
    city: 'Kent',
    state: 'WA',
    zip: '98032',
    address: '99 Summit Dental Loop',
    phone: '(253) 555-0180',
    fax: '(253) 555-0181',
    website: 'nwdentalexam.example',
    services: ['Comprehensive dental evaluation'],
    employerAccount: 'Unknown',
    corporateAccount: 'Unknown',
    tpaFriendly: 'Unknown',
    standingAccount: 'No',
    invoiceBilling: 'No',
    net30: 'No',
    acceptsOutsideForms: 'Yes',
    paymentAtService: 'Yes',
    requiresAgreement: 'No',
    verification: 'Verified',
    confidence: 88,
    lastReviewed: 'Today',
    source: 'Clinic confirmed DD2813 + bitewings',
    notes: 'Good for DD2813 only. Cleaning/treatment out of scope.',
    x: 14,
    y: 27,
  },
];

const savedSearches = [
  { name: 'Occupational Medicine Employer Services', count: 184, updated: 'Today', terms: 'employer services, occupational health, account setup' },
  { name: 'Urgent Care Employer Accounts', count: 132, updated: 'Yesterday', terms: 'urgent care employer services, corporate billing' },
  { name: 'Hospital Occupational Health Departments', count: 96, updated: '2 days ago', terms: 'hospital occupational medicine department' },
  { name: 'Imaging / Radiology for Chest X-ray', count: 211, updated: 'Today', terms: 'chest x-ray interpretation, radiology center' },
  { name: 'Treadmill Stress Test Providers', count: 48, updated: 'Today', terms: 'Bruce protocol, treadmill stress test, cardiology' },
  { name: 'Travel Vaccine / Yellow Fever Providers', count: 77, updated: '3 days ago', terms: 'yellow fever, rabies, typhoid, travel medicine' },
  { name: 'Dental DD2813 Providers', count: 64, updated: 'Today', terms: 'bitewing, panoramic, dental exam, outside forms' },
  { name: 'TPA-Friendly / NET Terms Clinics', count: 54, updated: 'Yesterday', terms: 'TPA, net terms, direct invoice billing' },
];

const trendData = [
  { day: 'Mon', providers: 22, verified: 7 },
  { day: 'Tue', providers: 41, verified: 19 },
  { day: 'Wed', providers: 67, verified: 29 },
  { day: 'Thu', providers: 93, verified: 44 },
  { day: 'Fri', providers: 121, verified: 58 },
  { day: 'Sat', providers: 152, verified: 79 },
  { day: 'Sun', providers: 188, verified: 104 },
];

const categoryData = [
  { name: 'Occ Med', value: 44 },
  { name: 'Urgent', value: 38 },
  { name: 'Imaging', value: 31 },
  { name: 'Dental', value: 18 },
  { name: 'Vaccines', value: 26 },
  { name: 'Cardio', value: 11 },
];

const stateCoverage = [
  { state: 'CA', coverage: 74 },
  { state: 'TX', coverage: 61 },
  { state: 'FL', coverage: 58 },
  { state: 'CO', coverage: 47 },
  { state: 'WA', coverage: 42 },
  { state: 'PA', coverage: 39 },
  { state: 'OH', coverage: 35 },
  { state: 'DE', coverage: 21 },
];

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Radar },
  { id: 'map', label: 'U.S. Coverage Map', icon: Globe2 },
  { id: 'database', label: 'Provider Database', icon: Table2 },
  { id: 'crawl', label: 'Search & Crawl', icon: Search },
  { id: 'saved', label: 'Saved Searches', icon: ClipboardCheck },
  { id: 'review', label: 'Review Queue', icon: ShieldCheck },
];

const statusColor: Record<VerificationStatus, string> = {
  Verified: 'bg-emerald-400/15 text-emerald-100 border-emerald-300/30',
  'Needs Review': 'bg-amber-400/15 text-amber-100 border-amber-300/30',
  Unverified: 'bg-fuchsia-400/15 text-fuchsia-100 border-fuchsia-300/30',
};

const triStateColor: Record<TriState, string> = {
  Yes: 'text-emerald-200 bg-emerald-400/10 border-emerald-300/25',
  No: 'text-rose-200 bg-rose-400/10 border-rose-300/25',
  Unknown: 'text-slate-200 bg-white/5 border-white/10',
};

const initialJobs: SearchJob[] = [
  {
    id: 1,
    name: 'Relentless Employer Services Sweep',
    query: 'occupational medicine employer services corporate billing',
    area: 'CA, TX, FL',
    zipScanned: 1428,
    providersFound: 188,
    highValue: 39,
    status: 'Running',
    progress: 68,
  },
  {
    id: 2,
    name: 'CXR + Interpretation Radiology Hunt',
    query: 'chest x-ray radiological interpretation cash pay employer',
    area: 'Nationwide',
    zipScanned: 4042,
    providersFound: 211,
    highValue: 22,
    status: 'Complete',
    progress: 100,
  },
  {
    id: 3,
    name: 'Stress Test Provider Search',
    query: 'treadmill stress test Bruce protocol interpretation employer',
    area: 'FL, TX, PA',
    zipScanned: 697,
    providersFound: 48,
    highValue: 12,
    status: 'Queued',
    progress: 18,
  },
];

function cn(...classes: Array<string | false | undefined | null>) {
  return classes.filter(Boolean).join(' ');
}

function Badge({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <span className={cn('inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-medium', className)}>{children}</span>;
}

function GlassCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn('rounded-[2rem] border border-white/12 bg-white/[0.065] shadow-[0_0_45px_rgba(217,70,239,0.12)] backdrop-blur-2xl', className)}>
      {children}
    </div>
  );
}

function MetricCard({ title, value, sub, icon: Icon }: { title: string; value: string; sub: string; icon: React.ComponentType<{ className?: string }> }) {
  return (
    <GlassCard className="group relative overflow-hidden p-5 transition hover:-translate-y-1 hover:border-fuchsia-300/30 hover:bg-white/[0.09]">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-fuchsia-300/70 to-transparent" />
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.24em] text-violet-100/55">{title}</p>
          <p className="mt-3 text-3xl font-semibold text-white">{value}</p>
          <p className="mt-1 text-sm text-violet-100/60">{sub}</p>
        </div>
        <div className="rounded-2xl border border-fuchsia-300/20 bg-fuchsia-400/10 p-3 text-fuchsia-100 shadow-[0_0_28px_rgba(217,70,239,0.25)]">
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </GlassCard>
  );
}

function ProviderDrawer({ provider, onClose }: { provider: Provider | null; onClose: () => void }) {
  if (!provider) return null;

  const fields: Array<[string, TriState]> = [
    ['Employer account', provider.employerAccount],
    ['Corporate account', provider.corporateAccount],
    ['TPA friendly', provider.tpaFriendly],
    ['Standing account', provider.standingAccount],
    ['Invoice billing', provider.invoiceBilling],
    ['NET 30', provider.net30],
    ['Accepts outside forms', provider.acceptsOutsideForms],
    ['Payment at service', provider.paymentAtService],
    ['Requires agreement', provider.requiresAgreement],
  ];

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/70 backdrop-blur-sm" onClick={onClose}>
      <div className="h-full w-full max-w-2xl overflow-y-auto border-l border-white/10 bg-[#090617]/95 p-6 shadow-[0_0_80px_rgba(217,70,239,0.22)]" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-4">
          <div>
            <Badge className={statusColor[provider.verification]}>{provider.verification}</Badge>
            <h2 className="mt-4 text-3xl font-semibold text-white">{provider.name}</h2>
            <p className="mt-2 text-violet-100/65">{provider.type}</p>
          </div>
          <button onClick={onClose} className="rounded-2xl border border-white/10 bg-white/5 p-3 text-violet-100 transition hover:bg-white/10">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <GlassCard className="p-4">
            <p className="text-xs uppercase tracking-[0.22em] text-violet-100/50">Contact</p>
            <p className="mt-3 text-sm text-white">{provider.address}</p>
            <p className="text-sm text-violet-100/65">{provider.city}, {provider.state} {provider.zip}</p>
            <p className="mt-3 text-sm text-violet-100/80">Phone: {provider.phone}</p>
            <p className="text-sm text-violet-100/80">Fax: {provider.fax}</p>
            <p className="text-sm text-fuchsia-100">{provider.website}</p>
          </GlassCard>
          <GlassCard className="p-4">
            <p className="text-xs uppercase tracking-[0.22em] text-violet-100/50">Intelligence</p>
            <p className="mt-3 text-sm text-white">Confidence score: {provider.confidence}%</p>
            <p className="text-sm text-violet-100/70">Last reviewed: {provider.lastReviewed}</p>
            <p className="mt-3 text-sm text-violet-100/70">Source: {provider.source}</p>
          </GlassCard>
        </div>

        <GlassCard className="mt-4 p-4">
          <p className="text-xs uppercase tracking-[0.22em] text-violet-100/50">Service capability</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {provider.services.map((service) => (
              <Badge key={service} className="border-cyan-300/25 bg-cyan-300/10 text-cyan-100">{service}</Badge>
            ))}
          </div>
        </GlassCard>

        <GlassCard className="mt-4 p-4">
          <p className="text-xs uppercase tracking-[0.22em] text-violet-100/50">Agreement / billing fit</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {fields.map(([label, value]) => (
              <div key={label} className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.035] px-3 py-2">
                <span className="text-sm text-violet-100/70">{label}</span>
                <Badge className={triStateColor[value]}>{value}</Badge>
              </div>
            ))}
          </div>
        </GlassCard>

        <GlassCard className="mt-4 p-4">
          <p className="text-xs uppercase tracking-[0.22em] text-violet-100/50">Recommended next action</p>
          <p className="mt-3 text-sm leading-6 text-violet-100/75">{provider.notes}</p>
          <div className="mt-4 rounded-2xl border border-fuchsia-300/20 bg-fuchsia-300/10 p-4 text-sm leading-6 text-fuchsia-50">
            Suggested outreach: confirm service availability, ask whether outside employer-provided forms can be completed, request pricing, and ask whether a provider agreement, corporate account, or direct invoice billing is available.
          </div>
        </GlassCard>
      </div>
    </div>
  );
}

function CoverageMap({ providers, onSelect }: { providers: Provider[]; onSelect: (provider: Provider) => void }) {
  return (
    <GlassCard className="relative overflow-hidden p-6">
      <div className="absolute inset-0 opacity-35" style={{ backgroundImage: "url('/hero-us-map-glow.png')", backgroundSize: 'cover', backgroundPosition: 'center' }} />
      <div className="absolute inset-0 bg-gradient-to-br from-[#080513]/80 via-[#130824]/70 to-[#05030d]/90" />
      <div className="relative z-10 flex flex-col gap-6 lg:flex-row">
        <div className="flex-1">
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-fuchsia-100/60">Live coverage grid</p>
              <h3 className="mt-2 text-2xl font-semibold text-white">United States Provider Coverage</h3>
            </div>
            <Badge className="border-fuchsia-300/25 bg-fuchsia-300/10 text-fuchsia-100">68% active sweep</Badge>
          </div>

          <div className="relative mt-8 h-[390px] overflow-hidden rounded-[2rem] border border-white/10 bg-black/20 shadow-inner">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_45%,rgba(217,70,239,0.22),transparent_34%),linear-gradient(rgba(255,255,255,0.04)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.04)_1px,transparent_1px)] bg-[size:100%_100%,44px_44px,44px_44px]" />
            <svg viewBox="0 0 900 520" className="absolute inset-0 h-full w-full opacity-90">
              <path d="M130,210 C170,120 260,90 360,120 C440,145 510,105 610,145 C705,180 780,240 760,325 C735,425 580,455 455,430 C355,410 265,440 185,380 C125,335 100,270 130,210 Z" fill="rgba(168,85,247,0.16)" stroke="rgba(240,171,252,0.55)" strokeWidth="3" />
              {stateCoverage.map((item, index) => {
                const positions = [
                  [165, 255], [455, 335], [660, 350], [370, 250], [180, 175], [675, 220], [610, 220], [720, 260],
                ];
                const [cx, cy] = positions[index];
                return (
                  <g key={item.state}>
                    <circle cx={cx} cy={cy} r={26 + item.coverage / 6} fill="rgba(217,70,239,0.08)" stroke="rgba(217,70,239,0.35)" />
                    <text x={cx} y={cy + 4} textAnchor="middle" fill="rgba(255,255,255,0.78)" fontSize="18" fontWeight="700">{item.state}</text>
                  </g>
                );
              })}
            </svg>

            {providers.map((provider) => (
              <button
                key={provider.id}
                onClick={() => onSelect(provider)}
                className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full border border-fuchsia-200/80 bg-fuchsia-300 p-1.5 shadow-[0_0_25px_rgba(244,114,182,0.95)] transition hover:scale-125"
                style={{ left: `${provider.x}%`, top: `${provider.y}%` }}
                title={provider.name}
              >
                <span className="block h-2 w-2 rounded-full bg-white" />
              </button>
            ))}

            <div className="absolute bottom-4 left-4 right-4 rounded-3xl border border-white/10 bg-slate-950/55 p-4 backdrop-blur-xl">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-medium text-white">Systematic ZIP coverage in progress</p>
                  <p className="text-xs text-violet-100/60">Markers represent provider leads discovered or seeded for verification workflow.</p>
                </div>
                <div className="h-2 w-48 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full w-[68%] rounded-full bg-gradient-to-r from-violet-400 via-fuchsia-400 to-pink-400 shadow-[0_0_18px_rgba(217,70,239,0.8)]" />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="w-full lg:w-80">
          <p className="text-xs uppercase tracking-[0.24em] text-violet-100/55">Coverage by state</p>
          <div className="mt-4 space-y-3">
            {stateCoverage.map((item) => (
              <div key={item.state} className="rounded-2xl border border-white/10 bg-white/[0.045] p-3">
                <div className="flex justify-between text-sm">
                  <span className="font-medium text-white">{item.state}</span>
                  <span className="text-fuchsia-100">{item.coverage}%</span>
                </div>
                <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-gradient-to-r from-violet-400 to-fuchsia-400" style={{ width: `${item.coverage}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </GlassCard>
  );
}

export default function Index() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [providers, setProviders] = useState<Provider[]>(providersSeed);
  const [selectedProvider, setSelectedProvider] = useState<Provider | null>(null);
  const [query, setQuery] = useState('');
  const [stateFilter, setStateFilter] = useState('All');
  const [serviceFilter, setServiceFilter] = useState('All');
  const [jobs, setJobs] = useState<SearchJob[]>(initialJobs);
  const [searchIntensity, setSearchIntensity] = useState('Relentless');

  const filteredProviders = useMemo(() => {
    return providers.filter((provider) => {
      const matchesQuery = !query || [provider.name, provider.type, provider.city, provider.state, provider.website, provider.services.join(' ')].join(' ').toLowerCase().includes(query.toLowerCase());
      const matchesState = stateFilter === 'All' || provider.state === stateFilter;
      const matchesService = serviceFilter === 'All' || provider.services.includes(serviceFilter);
      return matchesQuery && matchesState && matchesService;
    });
  }, [providers, query, stateFilter, serviceFilter]);

  const stats = useMemo(() => {
    const verified = providers.filter((p) => p.verification === 'Verified').length;
    const review = providers.filter((p) => p.verification === 'Needs Review').length;
    const states = new Set(providers.map((p) => p.state)).size;
    const highValue = providers.filter((p) => p.employerAccount === 'Yes' || p.invoiceBilling === 'Yes' || p.net30 === 'Yes').length;
    return { verified, review, states, highValue };
  }, [providers]);

  const startSimulatedSearch = () => {
    const newJob: SearchJob = {
      id: jobs.length + 1,
      name: `${searchIntensity} Provider Sweep`,
      query: query || 'employer services occupational medicine corporate billing outside forms',
      area: stateFilter === 'All' ? 'Nationwide' : stateFilter,
      zipScanned: Math.floor(Math.random() * 400) + 120,
      providersFound: Math.floor(Math.random() * 35) + 12,
      highValue: Math.floor(Math.random() * 9) + 3,
      status: 'Running',
      progress: Math.floor(Math.random() * 35) + 25,
    };
    setJobs([newJob, ...jobs]);
  };

  const verifyProvider = (id: number) => {
    setProviders((current) => current.map((provider) => provider.id === id ? { ...provider, verification: 'Verified', lastReviewed: 'Just now' } : provider));
  };

  const states = ['All', ...Array.from(new Set(providers.map((provider) => provider.state)))];

  return (
    <div className="min-h-screen overflow-hidden bg-[#05020d] text-white">
      <style>{`
        @keyframes pulseGlow { 0%, 100% { opacity: .45; transform: scale(1); } 50% { opacity: .9; transform: scale(1.04); } }
        @keyframes scanLine { 0% { transform: translateY(-100%); } 100% { transform: translateY(100vh); } }
        .glass-scroll::-webkit-scrollbar { width: 10px; height: 10px; }
        .glass-scroll::-webkit-scrollbar-thumb { background: rgba(217,70,239,.35); border-radius: 999px; }
      `}</style>

      <div className="fixed inset-0 bg-[radial-gradient(circle_at_15%_10%,rgba(168,85,247,0.24),transparent_28%),radial-gradient(circle_at_85%_25%,rgba(236,72,153,0.22),transparent_30%),radial-gradient(circle_at_50%_90%,rgba(59,130,246,0.16),transparent_38%)]" />
      <div className="fixed inset-0 opacity-30" style={{ backgroundImage: "url('/dashboard-bg.png')", backgroundSize: 'cover', backgroundPosition: 'center' }} />
      <div className="fixed left-0 top-0 h-screen w-px bg-fuchsia-300/70 shadow-[0_0_80px_28px_rgba(217,70,239,0.35)]" />
      <div className="fixed inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-fuchsia-300/70 to-transparent" />

      <div className="relative z-10 flex min-h-screen">
        <aside className="hidden w-80 shrink-0 border-r border-white/10 bg-white/[0.035] p-5 backdrop-blur-2xl xl:block">
          <div className="flex items-center gap-3 rounded-[1.8rem] border border-white/10 bg-white/[0.055] p-4">
            <div className="rounded-2xl border border-fuchsia-300/30 bg-fuchsia-400/15 p-3 shadow-[0_0_28px_rgba(217,70,239,0.35)]">
              <Building2 className="h-6 w-6 text-fuchsia-100" />
            </div>
            <div>
              <p className="text-sm font-semibold leading-tight">Occu-Med</p>
              <p className="text-xs text-violet-100/55">Provider Intelligence</p>
            </div>
          </div>

          <nav className="mt-6 space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={cn(
                    'flex w-full items-center justify-between rounded-2xl border px-4 py-3 text-left text-sm transition',
                    activeTab === item.id
                      ? 'border-fuchsia-300/35 bg-fuchsia-300/15 text-white shadow-[0_0_28px_rgba(217,70,239,0.18)]'
                      : 'border-transparent text-violet-100/65 hover:border-white/10 hover:bg-white/[0.055] hover:text-white'
                  )}
                >
                  <span className="flex items-center gap-3"><Icon className="h-4 w-4" /> {item.label}</span>
                  <ChevronRight className="h-4 w-4 opacity-50" />
                </button>
              );
            })}
          </nav>

          <GlassCard className="mt-6 p-4">
            <div className="flex items-center gap-3">
              <Activity className="h-5 w-5 text-fuchsia-100" />
              <div>
                <p className="text-sm font-medium text-white">Crawler mode</p>
                <p className="text-xs text-violet-100/55">Simulation workflow active</p>
              </div>
            </div>
            <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/10">
              <div className="h-full w-[68%] rounded-full bg-gradient-to-r from-violet-400 via-fuchsia-400 to-pink-400" />
            </div>
          </GlassCard>
        </aside>

        <main className="glass-scroll h-screen flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <header className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <Badge className="border-fuchsia-300/25 bg-fuchsia-300/10 text-fuchsia-100">Internal sourcing command center</Badge>
              <h1 className="mt-4 max-w-4xl text-4xl font-semibold tracking-tight text-white sm:text-5xl">
                Occu-Med Provider Intelligence Command Center
              </h1>
              <p className="mt-4 max-w-3xl text-base leading-7 text-violet-100/65">
                A glass Tahoe provider-sourcing cockpit for occupational health, employer accounts, TPA-friendly facilities, invoice-capable clinics, outside forms, and hard-to-source exam components.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <button onClick={startSimulatedSearch} className="rounded-2xl border border-fuchsia-300/30 bg-fuchsia-400/15 px-5 py-3 text-sm font-medium text-fuchsia-50 shadow-[0_0_30px_rgba(217,70,239,0.22)] transition hover:bg-fuchsia-300/20">
                Launch sweep
              </button>
              <button onClick={() => setActiveTab('database')} className="rounded-2xl border border-white/10 bg-white/[0.06] px-5 py-3 text-sm font-medium text-white transition hover:bg-white/10">
                View database
              </button>
            </div>
          </header>

          <div className="mt-6 flex gap-2 overflow-x-auto pb-2 xl:hidden">
            {navItems.map((item) => (
              <button key={item.id} onClick={() => setActiveTab(item.id)} className={cn('whitespace-nowrap rounded-2xl border px-4 py-2 text-sm', activeTab === item.id ? 'border-fuchsia-300/35 bg-fuchsia-300/15 text-white' : 'border-white/10 bg-white/5 text-violet-100/65')}>
                {item.label}
              </button>
            ))}
          </div>

          {activeTab === 'dashboard' && (
            <section className="mt-8 space-y-6">
              <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-4">
                <MetricCard title="Providers found" value={String(providers.length)} sub="Seeded intelligence records" icon={Database} />
                <MetricCard title="Verified" value={String(stats.verified)} sub={`${stats.review} need review`} icon={CheckCircle2} />
                <MetricCard title="States covered" value={String(stats.states)} sub="Expanding by ZIP sweep" icon={Globe2} />
                <MetricCard title="High-value leads" value={String(stats.highValue)} sub="Account or billing signals" icon={Target} />
              </div>

              <div className="grid gap-6 2xl:grid-cols-[1.35fr_.65fr]">
                <CoverageMap providers={providers} onSelect={setSelectedProvider} />
                <GlassCard className="p-5">
                  <p className="text-xs uppercase tracking-[0.24em] text-violet-100/55">Discovery velocity</p>
                  <h3 className="mt-2 text-xl font-semibold text-white">Weekly provider intelligence</h3>
                  <div className="mt-5 h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={trendData}>
                        <defs>
                          <linearGradient id="providers" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#d946ef" stopOpacity={0.65}/>
                            <stop offset="95%" stopColor="#d946ef" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid stroke="rgba(255,255,255,.08)" />
                        <XAxis dataKey="day" stroke="rgba(255,255,255,.45)" />
                        <YAxis stroke="rgba(255,255,255,.45)" />
                        <Tooltip contentStyle={{ background: '#12091f', border: '1px solid rgba(255,255,255,.12)', borderRadius: 18, color: '#fff' }} />
                        <Area type="monotone" dataKey="providers" stroke="#f0abfc" fill="url(#providers)" strokeWidth={3} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </GlassCard>
              </div>

              <div className="grid gap-6 xl:grid-cols-2">
                <GlassCard className="p-5">
                  <p className="text-xs uppercase tracking-[0.24em] text-violet-100/55">Provider mix</p>
                  <div className="mt-5 h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={categoryData}>
                        <CartesianGrid stroke="rgba(255,255,255,.08)" />
                        <XAxis dataKey="name" stroke="rgba(255,255,255,.45)" />
                        <YAxis stroke="rgba(255,255,255,.45)" />
                        <Tooltip contentStyle={{ background: '#12091f', border: '1px solid rgba(255,255,255,.12)', borderRadius: 18, color: '#fff' }} />
                        <Bar dataKey="value" fill="#d946ef" radius={[12, 12, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </GlassCard>

                <GlassCard className="p-5">
                  <p className="text-xs uppercase tracking-[0.24em] text-violet-100/55">Active search jobs</p>
                  <div className="mt-5 space-y-3">
                    {jobs.slice(0, 3).map((job) => (
                      <div key={job.id} className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="font-medium text-white">{job.name}</p>
                            <p className="mt-1 text-xs text-violet-100/55">{job.area} · {job.zipScanned.toLocaleString()} ZIPs scanned</p>
                          </div>
                          <Badge className="border-fuchsia-300/25 bg-fuchsia-300/10 text-fuchsia-100">{job.status}</Badge>
                        </div>
                        <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/10">
                          <div className="h-full rounded-full bg-gradient-to-r from-violet-400 via-fuchsia-400 to-pink-400" style={{ width: `${job.progress}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </GlassCard>
              </div>
            </section>
          )}

          {activeTab === 'map' && (
            <section className="mt-8 space-y-6">
              <div className="grid gap-4 lg:grid-cols-4">
                <select value={stateFilter} onChange={(e) => setStateFilter(e.target.value)} className="rounded-2xl border border-white/10 bg-white/[0.07] px-4 py-3 text-sm text-white outline-none backdrop-blur-xl">
                  {states.map((state) => <option key={state} className="bg-slate-950">{state}</option>)}
                </select>
                <select value={serviceFilter} onChange={(e) => setServiceFilter(e.target.value)} className="rounded-2xl border border-white/10 bg-white/[0.07] px-4 py-3 text-sm text-white outline-none backdrop-blur-xl lg:col-span-2">
                  <option className="bg-slate-950">All</option>
                  {services.map((service) => <option key={service} className="bg-slate-950">{service}</option>)}
                </select>
                <button className="rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 text-sm text-white"><Filter className="mr-2 inline h-4 w-4" />More filters</button>
              </div>
              <CoverageMap providers={filteredProviders} onSelect={setSelectedProvider} />
            </section>
          )}

          {activeTab === 'database' && (
            <section className="mt-8 space-y-5">
              <GlassCard className="p-4">
                <div className="grid gap-3 lg:grid-cols-[1fr_160px_260px]">
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-violet-100/45" />
                    <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search providers, services, city, account terms..." className="w-full rounded-2xl border border-white/10 bg-white/[0.06] py-3 pl-11 pr-4 text-sm text-white placeholder:text-violet-100/35 outline-none focus:border-fuchsia-300/40" />
                  </div>
                  <select value={stateFilter} onChange={(e) => setStateFilter(e.target.value)} className="rounded-2xl border border-white/10 bg-white/[0.07] px-4 py-3 text-sm text-white outline-none">
                    {states.map((state) => <option key={state} className="bg-slate-950">{state}</option>)}
                  </select>
                  <select value={serviceFilter} onChange={(e) => setServiceFilter(e.target.value)} className="rounded-2xl border border-white/10 bg-white/[0.07] px-4 py-3 text-sm text-white outline-none">
                    <option className="bg-slate-950">All</option>
                    {services.map((service) => <option key={service} className="bg-slate-950">{service}</option>)}
                  </select>
                </div>
              </GlassCard>

              <GlassCard className="overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[1180px] text-left text-sm">
                    <thead className="border-b border-white/10 bg-white/[0.04] text-xs uppercase tracking-[0.16em] text-violet-100/50">
                      <tr>
                        <th className="px-5 py-4">Provider</th>
                        <th className="px-5 py-4">Location</th>
                        <th className="px-5 py-4">Services</th>
                        <th className="px-5 py-4">Employer</th>
                        <th className="px-5 py-4">Invoice</th>
                        <th className="px-5 py-4">Outside Forms</th>
                        <th className="px-5 py-4">Status</th>
                        <th className="px-5 py-4">Score</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/10">
                      {filteredProviders.map((provider) => (
                        <tr key={provider.id} onClick={() => setSelectedProvider(provider)} className="cursor-pointer transition hover:bg-fuchsia-300/10">
                          <td className="px-5 py-4">
                            <p className="font-medium text-white">{provider.name}</p>
                            <p className="mt-1 text-xs text-violet-100/50">{provider.type}</p>
                          </td>
                          <td className="px-5 py-4 text-violet-100/70">{provider.city}, {provider.state} {provider.zip}</td>
                          <td className="px-5 py-4"><div className="flex max-w-sm flex-wrap gap-1.5">{provider.services.slice(0, 3).map((s) => <Badge key={s} className="border-cyan-300/20 bg-cyan-300/10 text-cyan-100">{s}</Badge>)}</div></td>
                          <td className="px-5 py-4"><Badge className={triStateColor[provider.employerAccount]}>{provider.employerAccount}</Badge></td>
                          <td className="px-5 py-4"><Badge className={triStateColor[provider.invoiceBilling]}>{provider.invoiceBilling}</Badge></td>
                          <td className="px-5 py-4"><Badge className={triStateColor[provider.acceptsOutsideForms]}>{provider.acceptsOutsideForms}</Badge></td>
                          <td className="px-5 py-4"><Badge className={statusColor[provider.verification]}>{provider.verification}</Badge></td>
                          <td className="px-5 py-4 text-fuchsia-100">{provider.confidence}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </GlassCard>
            </section>
          )}

          {activeTab === 'crawl' && (
            <section className="mt-8 grid gap-6 xl:grid-cols-[.8fr_1.2fr]">
              <GlassCard className="p-6">
                <p className="text-xs uppercase tracking-[0.24em] text-violet-100/55">Launch search workflow</p>
                <h2 className="mt-2 text-2xl font-semibold text-white">Search & Crawl Controls</h2>
                <p className="mt-3 text-sm leading-6 text-violet-100/60">This prototype simulates the provider-intelligence workflow. Connect approved data sources later to turn these controls into live search jobs.</p>
                <div className="mt-6 space-y-4">
                  <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Example: occupational medicine employer services net terms" className="w-full rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 text-sm text-white placeholder:text-violet-100/35 outline-none" />
                  <select value={stateFilter} onChange={(e) => setStateFilter(e.target.value)} className="w-full rounded-2xl border border-white/10 bg-white/[0.07] px-4 py-3 text-sm text-white outline-none">
                    {states.map((state) => <option key={state} className="bg-slate-950">{state}</option>)}
                  </select>
                  <select value={searchIntensity} onChange={(e) => setSearchIntensity(e.target.value)} className="w-full rounded-2xl border border-white/10 bg-white/[0.07] px-4 py-3 text-sm text-white outline-none">
                    {['Standard', 'Aggressive', 'Relentless'].map((mode) => <option key={mode} className="bg-slate-950">{mode}</option>)}
                  </select>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {['Employer accounts', 'TPA language', 'Invoice billing', 'Outside forms', 'Self-pay terms', 'Hospital occ med'].map((flag) => (
                      <label key={flag} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] px-3 py-3 text-sm text-violet-100/75">
                        <input type="checkbox" defaultChecked className="accent-fuchsia-400" /> {flag}
                      </label>
                    ))}
                  </div>
                  <button onClick={startSimulatedSearch} className="w-full rounded-2xl border border-fuchsia-300/30 bg-fuchsia-400/15 px-5 py-3 font-medium text-fuchsia-50 shadow-[0_0_30px_rgba(217,70,239,0.22)] transition hover:bg-fuchsia-300/20">
                    <Play className="mr-2 inline h-4 w-4" /> Start simulated sweep
                  </button>
                </div>
              </GlassCard>

              <div className="space-y-4">
                {jobs.map((job) => (
                  <GlassCard key={job.id} className="p-5">
                    <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <Badge className="border-fuchsia-300/25 bg-fuchsia-300/10 text-fuchsia-100">{job.status}</Badge>
                          <Badge className="border-cyan-300/25 bg-cyan-300/10 text-cyan-100">{job.area}</Badge>
                        </div>
                        <h3 className="mt-3 text-xl font-semibold text-white">{job.name}</h3>
                        <p className="mt-2 text-sm text-violet-100/60">{job.query}</p>
                      </div>
                      <button className="rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-2 text-sm text-white"><Pause className="mr-2 inline h-4 w-4" />Pause</button>
                    </div>
                    <div className="mt-5 grid gap-3 sm:grid-cols-3">
                      <div className="rounded-2xl bg-white/[0.04] p-3"><p className="text-xs text-violet-100/45">ZIPs scanned</p><p className="mt-1 text-xl text-white">{job.zipScanned.toLocaleString()}</p></div>
                      <div className="rounded-2xl bg-white/[0.04] p-3"><p className="text-xs text-violet-100/45">Providers found</p><p className="mt-1 text-xl text-white">{job.providersFound}</p></div>
                      <div className="rounded-2xl bg-white/[0.04] p-3"><p className="text-xs text-violet-100/45">High-value</p><p className="mt-1 text-xl text-white">{job.highValue}</p></div>
                    </div>
                    <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/10">
                      <div className="h-full rounded-full bg-gradient-to-r from-violet-400 via-fuchsia-400 to-pink-400" style={{ width: `${job.progress}%` }} />
                    </div>
                  </GlassCard>
                ))}
              </div>
            </section>
          )}

          {activeTab === 'saved' && (
            <section className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {savedSearches.map((search) => (
                <GlassCard key={search.name} className="p-5 transition hover:-translate-y-1 hover:border-fuchsia-300/30">
                  <div className="flex items-start justify-between gap-4">
                    <div className="rounded-2xl border border-fuchsia-300/20 bg-fuchsia-300/10 p-3"><FileCheck2 className="h-5 w-5 text-fuchsia-100" /></div>
                    <Badge className="border-white/10 bg-white/5 text-violet-100">{search.count} results</Badge>
                  </div>
                  <h3 className="mt-5 text-lg font-semibold text-white">{search.name}</h3>
                  <p className="mt-2 text-sm leading-6 text-violet-100/60">{search.terms}</p>
                  <div className="mt-5 flex items-center justify-between text-sm">
                    <span className="text-violet-100/50">Last run: {search.updated}</span>
                    <button onClick={startSimulatedSearch} className="rounded-xl border border-fuchsia-300/25 bg-fuchsia-300/10 px-3 py-2 text-fuchsia-100">Run</button>
                  </div>
                </GlassCard>
              ))}
            </section>
          )}

          {activeTab === 'review' && (
            <section className="mt-8 space-y-4">
              {providers.filter((p) => p.verification !== 'Verified').map((provider) => (
                <GlassCard key={provider.id} className="p-5">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                    <div>
                      <div className="flex flex-wrap gap-2">
                        <Badge className={statusColor[provider.verification]}>{provider.verification}</Badge>
                        <Badge className="border-fuchsia-300/25 bg-fuchsia-300/10 text-fuchsia-100">Priority {provider.confidence > 80 ? 'High' : 'Medium'}</Badge>
                      </div>
                      <h3 className="mt-3 text-xl font-semibold text-white">{provider.name}</h3>
                      <p className="mt-1 text-sm text-violet-100/60">{provider.notes}</p>
                      <p className="mt-2 text-xs text-violet-100/45">Missing/confirm: pricing sheet, account setup terms, outside forms, service list</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button onClick={() => setSelectedProvider(provider)} className="rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-2 text-sm text-white">Open</button>
                      <button onClick={() => verifyProvider(provider.id)} className="rounded-2xl border border-emerald-300/25 bg-emerald-300/10 px-4 py-2 text-sm text-emerald-100">Mark verified</button>
                      <button className="rounded-2xl border border-amber-300/25 bg-amber-300/10 px-4 py-2 text-sm text-amber-100"><Phone className="mr-2 inline h-4 w-4" />Needs call</button>
                    </div>
                  </div>
                </GlassCard>
              ))}
            </section>
          )}
        </main>
      </div>

      <ProviderDrawer provider={selectedProvider} onClose={() => setSelectedProvider(null)} />
    </div>
  );
}
